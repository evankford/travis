<?php

return array(
    'textbox' => '_text',
    'checkbox' => '_checkbox',
    'listselect' => '_list-dropdown',
    'listradio' => '_list-radio',
    'listcheckbox' => '_list-checkbox',
    'listmultiselect' => '_list-multi',
    'submit' => '_submit',
    'spam' => '_spam',
    'textarea' => '_textarea',
    'password' => '_profile_pass',
    'starrating' => '_rating',
    'listcountry' => '_country',
    'number' => '_number',
    'hr' => '_hr',
    'file_upload' => '_upload'
);