<input type='text' class='code widefat' name='<?php echo $view->get_field_name( $data ); ?>' id='<?php echo $view->get_field_name( $data ); ?>' value='<?php echo $view->get_field_value( $data ); ?>'>
